CREATE TABLE Agencias
( CdAgencia	CHAR(4)           NOT NULL,
  NmAgencia	VARCHAR(30)	  NOT NULL,
  EndAgencia	VARCHAR(50)  NULL,
  TelAgencia	VARCHAR(15)  NOT NULL ) ;

CREATE TABLE Clientes
( CdCliente	CHAR(5)           NOT NULL,
  NmCliente	VARCHAR(40)	  NOT NULL,
  EndCliente	VARCHAR(50)  NOT NULL,
  TelCliente	VARCHAR(15)  NULL,
  SexCliente    CHAR(1)       NOT NULL,
  DtNasCliente  DATE          NULL,
  CPFCliente	VARCHAR(15)  NOT NULL,
  RGCliente	VARCHAR(15)      NOT NULL ) ;

CREATE TABLE CliContas
( CdCliente	CHAR(5)		NOT NULL,
  NrConta	CHAR(4)		NOT NULL,
  Senha		VARCHAR(8) NULL ) ;

CREATE TABLE Contas
( NrConta	CHAR(4)		 NOT NULL,
  DtAbertura	DATE 	 NOT NULL,
  CdAgencia	CHAR(4)		 NOT NULL,
  VrSaldo	numeric(10,2) NULL ) ;

CREATE TABLE Movimentos
( NrMov		numeric(12,0)    NOT NULL,
  NrConta	CHAR(4)		  NOT NULL,
  DtMov		DATE 		  NOT NULL,
  TpMov		CHAR(1)		  NOT NULL,
  VrMov		numeric(12,2)  NOT NULL,
  DsMov		VARCHAR(20)  NOT NULL,
  VrSaldo	numeric(12,2)  NULL ) ;

--
-- Definindo as chaves primárias de cada tabela
--
ALTER TABLE Agencias   ADD CONSTRAINT PK_Agencias   PRIMARY KEY( CdAgencia ) ;

ALTER TABLE Clientes   ADD CONSTRAINT PK_Clientes   PRIMARY KEY( CdCliente ) ;

ALTER TABLE CliContas  ADD CONSTRAINT PK_CliContas  PRIMARY KEY( NrConta, CdCliente ) ;

ALTER TABLE Contas     ADD CONSTRAINT PK_Contas     PRIMARY KEY( NrConta ) ;

ALTER TABLE Movimentos ADD CONSTRAINT PK_Movimentos PRIMARY KEY( NrMov ) ;

--
-- Definindo as outras restrições
--
ALTER TABLE Agencias   ADD CONSTRAINT UK_Age_NmAgencia  UNIQUE( NmAgencia ) ;

ALTER TABLE Clientes   ADD CONSTRAINT CK_Cli_SexCliente CHECK( SexCliente IN( 'M', 'F' )) ;

ALTER TABLE CliContas  ADD CONSTRAINT FK_CCo_Cli        FOREIGN KEY( CdCliente ) REFERENCES Clientes ;

ALTER TABLE CliContas  ADD CONSTRAINT FK_CCo_Con        FOREIGN KEY( NrConta )   REFERENCES Contas ;

ALTER TABLE Contas     ADD CONSTRAINT FK_Con_Age        FOREIGN KEY( CdAgencia ) REFERENCES Agencias ;

ALTER TABLE Contas     ADD CONSTRAINT CK_Con_VrSaldo    CHECK( VrSaldo >= 0 ) ;

ALTER TABLE Movimentos ADD CONSTRAINT FK_Mov_Con        FOREIGN KEY( NrConta ) REFERENCES Contas ;

ALTER TABLE Movimentos ADD CONSTRAINT CK_Mov_VrMov      CHECK( VrMov > 0 ) ;

ALTER TABLE Movimentos ADD CONSTRAINT CK_Mov_VrSaldo    CHECK( VrSaldo >= 0 ) ;

ALTER TABLE Movimentos ADD CONSTRAINT CK_Mov_TpMov      CHECK ( TpMov IN( 'C', 'D' ) ) ;

-- *
-- * Fim deste script
-- *

DROP TABLE CLIENTES; 


select max(salario) maximo,
 min(salario) minimo,
 sum(salario) soma,
 avg(salario) media
from empregado


SELECT 
    M.DtMov AS Data, 
    M.VrMov AS Valor, 
    M.TpMov AS Tipo_de_Movimento, 
    M.NrConta AS Numero_da_Conta
FROM 
    Clientes C
JOIN 
    CliContas CC ON C.CdCliente = CC.CdCliente
JOIN 
    Movimentos M ON CC.NrConta = M.NrConta
WHERE 
    C.NmCliente = 'JOAO DA SILVA' AND M.TPMOV = 'D'
ORDER BY 
    M.DtMov;
    
    
    
    NSERT INTO Clientes
	VALUES ( '00099', 'Matheus Alvares', 'RIO TIETE, 69',
		 '6969-6969', 'M', '01/01/1970', '888.888.888-89', '9928288' ) ;
        
        
        
        
INSERT INTO Contas
	VALUES ( '1033', '12/12/1995', '0060', 0 ) ;
    
INSERT INTO CliContas
	VALUES ( '00099', '1033', NULL ) ;
    
SELECT C.NMCLIENTE AS NOME_CLIENTE,
    CT.NRCONTA AS NUMERO_CONTA
    FROM CLIENTES C
    JOIN CLICONTAS CC ON C.CDCLIENTE = CC.CDCLIENTE 
    JOIN CONTAS CT ON CC.NRCONTA = CT.NRCONTA 
    WHERE C.NMCLIENTE = 'Matheus Alvares'
    ORDER BY C.NMCLIENTE; 
    

SELECT A.NMAGENCIA AS NOME_AGENCIA,
        SUM(M.VRMOV) 
        FROM AGENCIAS A  
        JOIN CONTAS C ON A.CDAGENCIA = C.CDAGENCIA 
        JOIN MOVIMENTOS M ON M.NRCONTA = C.NRCONTA
        WHERE M.TPMOV = 'D'
        GROUP BY A.NMAGENCIA
        HAVING SUM(M.VRMOV) >= 400; 



DELETE FROM MOVIMENTOS
WHERE NRCONTA IN (
    SELECT NRCONTA
    FROM CLICONTAS
    WHERE CDCLIENTE = (SELECT CDCLIENTE FROM CLIENTES WHERE NMCLIENTE = 'ANTONIO DOS SANTOS')
);

-- 2. Excluir as contas correntes do cliente
DELETE FROM CLICONTAS
WHERE CDCLIENTE = (SELECT CDCLIENTE FROM CLIENTES WHERE NMCLIENTE = 'ANTONIO DOS SANTOS');

-- 3. Excluir o cliente
DELETE FROM CLIENTES
WHERE NMCLIENTE = 'ANTONIO DOS SANTOS';



    
